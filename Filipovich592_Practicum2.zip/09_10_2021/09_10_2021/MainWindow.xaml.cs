﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _09_10_2021
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double tmp = Convert.ToDouble(inputTextbox.Text);
            if (tmp < 100 && tmp > 9 && tmp == Math.Round(tmp))
            {
                int a = Convert.ToInt32(tmp);
                if (a % 2 == 0)
                    multiplesByTwoTextBox.Text = "число кратно двум";
                else multiplesByTwoTextBox.Text = "число не кратно двум";
                if (a % 3 == 0)
                    multiplesByThreeTextBox.Text = "число кратно трём";
                else multiplesByThreeTextBox.Text = "число не кратно трём";
                multTextBox.Text = Convert.ToString(a / 10 * a % 10);
                sumTextBox.Text = Convert.ToString(a / 10 + a % 10);
            }
            else
                MessageBox.Show("Вы ввели не двузначное целое число");
            }
            catch(System.FormatException)
            {
                MessageBox.Show("Вы ввели не двузначное целое число");
            }
        }
    }
}
